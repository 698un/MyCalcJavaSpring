


//вектор
class Vector2{
    constructor(){
        this.x = 0;
        this.y = 0;
        }//constructor vector2

    set(ix,iy){
        this.x = ix;
        this.y = iy;
        }



    }//class Vector2

class Vector3{
    constructor(){
        this.x = 0;
        this.y = 0;
        this.z = 0;
        }//constructor vector2

    set(ix,iy,iz){
        this.x = ix;
        this.y = iy;
        this.z = iz;
        }
    }//class Vector2




