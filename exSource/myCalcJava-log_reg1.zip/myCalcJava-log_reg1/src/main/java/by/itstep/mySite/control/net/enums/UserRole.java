package by.itstep.mySite.control.net.enums;

public enum UserRole {
    GUEST,CLIENT,ROOT;
    }
