package by.itstep.mySite.control.net.enums;


/*
This is type of client request
 -  get file(for browser)
 -  post resultat
 -  post command


 */
public enum RequestType {
    WebResultat,WebFile,WebData,Unknow;
    }
