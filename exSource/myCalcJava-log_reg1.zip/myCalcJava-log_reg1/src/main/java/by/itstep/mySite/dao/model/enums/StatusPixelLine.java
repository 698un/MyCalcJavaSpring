package by.itstep.mySite.dao.model.enums;

public enum StatusPixelLine {
    NULL, PROCESS, COMPLETTE
}
