package by.itstep.mySite.service;

public class AcceptException extends Exception{

    public AcceptException(String message){
        super(message);
        }//constructor





    }//AcceptException
