
package by.itstep.mySite.control.net.enums;
/**
 * Created by 698UN on 11.09.2021.
 */
public enum HttpType {
    GET,POST,DELETE,UNKNOW;
    }
