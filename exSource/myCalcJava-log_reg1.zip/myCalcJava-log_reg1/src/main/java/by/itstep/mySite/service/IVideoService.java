package by.itstep.mySite.service;

public interface IVideoService {
    void createVideo(String fileName);

}
