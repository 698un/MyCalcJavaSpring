
package by.itstep.mySite.utilits.loger;

public enum LogState{
    FATAL,ERROR,WARN,INFO,DEBUG,TRACE,ALL
    }