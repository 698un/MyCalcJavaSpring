package by.itstep.mySite.service;


public class CalcException extends Exception{

    public CalcException(String message){
        super(message);
    }


}
